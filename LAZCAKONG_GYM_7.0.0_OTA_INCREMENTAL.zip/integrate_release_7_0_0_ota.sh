#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# Script Seguro de Integración Incremental: LAZCAKONG GYM 7.0.0 + OTA
# Base obligatoria: Lazcakong-33/LAZCAKONGYM @ migration/zero-cost
# Rama resultante:  release/7.0.0-ota
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${1:-$(pwd)}"
TARGET_BRANCH="release/7.0.0-ota"
BASE_BRANCH="migration/zero-cost"

if [ ! -d "$REPO_DIR/.git" ]; then
  echo "ERROR: '$REPO_DIR' no es un clon Git válido de Lazcakong-33/LAZCAKONGYM."
  echo "Uso: bash $0 /ruta/al/clon/LAZCAKONGYM"
  exit 1
fi

cd "$REPO_DIR"

echo "[1/7] Verificando repositorio e integridad SHA-256 del paquete incremental..."
REMOTE_URL="$(git remote get-url origin || true)"
if [[ "$REMOTE_URL" != *"LAZCAKONGYM"* ]]; then
  echo "ERROR: Remote origin inesperado ($REMOTE_URL). Abortando por seguridad."
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "ERROR: El árbol Git tiene cambios sin confirmar. Limpia o confirma cambios antes de continuar."
  exit 1
fi

(cd "$SCRIPT_DIR" && sha256sum -c SHA256SUMS.txt)

echo "[2/7] Sincronizando rama base $BASE_BRANCH y creando $TARGET_BRANCH sin sobrescribir Cloudflare/Neck/Zero-Cost..."
git fetch origin --tags
git checkout "$BASE_BRANCH"
git pull --ff-only origin "$BASE_BRANCH"

if git show-ref --verify --quiet "refs/heads/$TARGET_BRANCH"; then
  git checkout "$TARGET_BRANCH"
else
  git checkout -b "$TARGET_BRANCH" "$BASE_BRANCH"
fi

echo "[3/7] Aplicando ÚNICAMENTE los archivos nuevos y fusionados desde payload/..."
cp -a "$SCRIPT_DIR/payload/." "$REPO_DIR/"

for preserved in \
  "cloudflare/app-preview-worker.ts" \
  "wrangler.jsonc" \
  "src/components/NeckMovementDemo.tsx" \
  "src/data/neckExerciseAdditions.ts" \
  "src/utils/coachLocalFallback.ts" \
  "src/utils/otaCompatibility.ts"; do
  if [ ! -f "$preserved" ]; then
    echo "ERROR: Archivo exclusivo de migration/zero-cost ausente tras copia: $preserved"
    exit 1
  fi
done

if find . -maxdepth 3 \( -name ".env" -o -name "*.keystore" -o -name "*.jks" -o -name "google-services.json" \) | grep -q .; then
  echo "ERROR: Se detectaron archivos sensibles locales; aborte antes de hacer commit."
  exit 1
fi

echo "[4/7] Ejecutando lint, compilación y todas las suites de verificación..."
npm ci --no-audit --no-fund
npm run lint
npm run build

if [ -n "${VITE_PREVIEW_FIREBASE_CONFIG:-}" ]; then
  npm run build -- --mode cloudflare-preview
fi

export CI_ANDROID_ONLY=true
npx tsx src/server/__tests__/adminAccessRepairSuite.ts
npx tsx src/server/__tests__/pwaStartupSessionSuite.ts
npx tsx src/server/__tests__/nativeGoogleAuthSuite.ts
npx tsx src/server/__tests__/nativeAndroidRestRepairSuite.ts
npx tsx src/server/__tests__/nativeCapacitorStage7aSuite.ts
npx tsx src/server/__tests__/offlineProductionReadinessSuite.ts
npx tsx src/server/__tests__/otaUpdateSystemSuite.ts
npx tsx src/server/__tests__/neckLibrarySuite.ts
npx tsx src/server/__tests__/coachChatRecoverySuite.ts
npx tsx src/server/__tests__/coachLaunchReadinessSuite.ts
npx tsx src/server/__tests__/coachNoHangSuite.ts
node --test scripts/zero-cost-guard.test.mjs

echo "[5/7] Verificando que el tag v7.0.0 NO exista previamente en remoto..."
if git ls-remote --tags origin "refs/tags/v7.0.0" | grep -q "v7.0.0"; then
  echo "AVISO: El tag v7.0.0 ya existe en GitHub. Usa una versión incremental (ej. 7.0.1 / v7.0.1) antes de lanzar Release."
else
  echo "OK: Tag v7.0.0 disponible (sin colisión)."
fi

echo "[6/7] Revisando estado Git antes del commit..."
git status --short

echo "[7/7] Listo para commit, push y disparo controlado de GitHub Actions:"
cat << 'NEXTSTEPS'

Ejecuta para publicar la rama de integración y lanzar la APK Release 7.0.0 (Pre-release, canal staging):

  git add -A
  git commit -m "release: integrate LAZCAKONG GYM 7.0.0 OTA & recovery onto migration/zero-cost"
  git push -u origin release/7.0.0-ota

  gh workflow run android-apk.yml \
    --ref release/7.0.0-ota \
    -f build_type=release \
    -f generate_ota_bundle=true \
    -f ota_channel=staging \
    -f publish_github_release=true \
    -f version_name=7.0.0 \
    -f version_code=70000 \
    -f release_notes="LAZCAKONG GYM 7.0.0 (Pre-release staging): OTA Ed25519 y soporte nativo Android."

Nota: Mantén OTA_PRODUCTION_ENABLED=false hasta validar físicamente app-release.apk y OTA en Android.
NEXTSTEPS
