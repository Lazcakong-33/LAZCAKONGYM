# Inventario Exacto de Integración Incremental — LAZCAKONG GYM 7.0.0 (OTA + APK Release)

- **Repositorio destino**: `https://github.com/Lazcakong-33/LAZCAKONGYM`
- **Rama base obligatoria**: `migration/zero-cost`
- **Rama de integración a crear**: `release/7.0.0-ota`
- **Identificador Android preservado**: `com.lazcakong.gym`
- **Versión objetivo**: `7.0.0` (`versionCode: 70000`)
- **Canal inicial OTA**: `staging` (con `OTA_PRODUCTION_ENABLED=false` y Pre-release en GitHub hasta validación en dispositivo real Android)
- **Total archivos en `payload/`**: 33

---

## 1. Archivos NUEVOS incluidos en `payload/` (3)

1. `src/components/AdminUpdateCenter.tsx` — Centro de Actualizaciones en el panel Admin (canales `development`/`staging`/`production`, sincronización GitHub Releases, descarga APK Release oficial, rollback y telemetría de dispositivos).
2. `src/components/ErrorBoundary.tsx` — Contenedor de recuperación ante errores sin pérdida de datos locales ni cierres abruptos.
3. `src/server/__tests__/recoveryBatchFixes.test.ts` — Suite automatizada para fallbacks REST de invitaciones/admin, fallback Google redirect y guardas de Service Worker/MIME.

---

## 2. Archivos ACTUALIZADOS / FUSIONADOS sobre `migration/zero-cost` (30)

### 2.1 Android, Capacitor & CI/CD
- `.github/workflows/android-apk.yml` — Fusionado: conserva la matriz de SDK 36 / JDK 21 / `setup-gradle@v4` / `apksigner` / `aapt` / suites `neckLibrarySuite`, `coachChatRecoverySuite`, `coachLaunchReadinessSuite`, `coachNoHangSuite`, `zero-cost-guard.test.mjs`, `CI_ANDROID_ONLY=true` y el job `publish-development-ota` de `migration/zero-cost`; añade compilación `release` 7.0.0 (`versionCode 70000`), empaquetado OTA firmado con Ed25519 + `SHA256SUMS.txt`, publicación en GitHub Releases (Pre-release cuando `OTA_PRODUCTION_ENABLED != 'true'`) y desacopla `VITE_API_BASE_URL` mediante `vars.LAZCAKONG_API_BASE_URL || 'https://lazcakongym.ai.studio'`.
- `android/app/build.gradle` — `applicationId "com.lazcakong.gym"`, `versionCode` por defecto `70000`, `versionName` `"7.0.0"`, firma exclusivamente por secretos CI (`LAZCAKONG_KEYSTORE_FILE` / `LAZCAKONG_DEBUG_KEYSTORE_FILE`).
- `android/gradlew.bat` — Script wrapper Gradle actualizado.
- `scripts/package-ota-bundle.mjs` — Empaquetador ZIP OTA (`SHA256SUMS.txt`, bloqueo en `production` sin `OTA_MANIFEST_PRIVATE_KEY_PEM` ni `OTA_PRODUCTION_ENABLED=true`, lectura compatible de `DEFAULT_APP_VERSION`/`APP_VERSION`).

### 2.2 Motor OTA, Banner, PWA y Configuraciones Compartidas
- `src/utils/updateApp.ts` — Mantiene inyección dinámica `VITE_APP_VERSION` de `migration/zero-cost` con respaldo `v7.0.0` (`7.0.0-ota-release`) y bloqueo seguro durante entrenamientos activos o colas offline.
- `src/utils/otaUpdateEngine.ts` — Mantiene `DEV_GITHUB_OTA_MANIFEST_URL` de `migration/zero-cost` y añade verificación obligatoria Ed25519 en `production`, backoff y cuarentena tras 3 fallos, rollback automático anti boot-loop (<90s), progreso de descarga, aviso post-instalación y telemetría autenticada.
- `src/hooks/useAppUpdate.ts` — Elimina polling permanente de 25s (objetivo Zero-Cost: cooldown 15 min al retomar / 30 min en segundo plano visible), conserva `Actualizar ahora`, descarga en segundo plano sin interrumpir entrenamientos y descarga segura de APK sin `window.open`.
- `src/components/UpdateBanner.tsx` — Banner verde lima/negro con progreso %, aviso de entrenamiento activo pospuesto, botón «Actualizar ahora», aviso de APK requerida y confirmación post-instalación.
- `src/server/otaUpdateController.ts` — Verificación criptográfica Ed25519 obligatoria para `production`, endpoints Admin (`/api/admin/ota/*`) y telemetría (`/api/ota/telemetry`), además de `resetOtaControlStateForTest`.
- `public/sw.js` — Versión `lazcakongym-v7.0.0-ota` con protección estricta anti-envenenamiento MIME (`text/html`).
- `.env.example` — Conserva `VITE_COACH_LOCAL_ONLY=false` y `LAZCAKONG_ZERO_COST_MODE=false` de `migration/zero-cost` y añade `OTA_MANIFEST_PUBLIC_KEY_PEM` y `OTA_REQUIRE_SIGNATURE`.
- `vite.config.ts` — Conserva íntegramente el modo `cloudflare-preview` (`isolated-firebase-preview` sobre `./src/firebase-applet-config.json`, `dist-app-preview`, `VITE_COACH_LOCAL_ONLY`, `VITE_COACH_WORKERS_AI`) de `migration/zero-cost` y actualiza `/api/version` a `7.0.0` / `7.0.0-ota-release`.
- `server.ts` — Conserva `/api/coach/status` y `generationSource`/`generationNotice` en `/api/gemini/generate-routine` de `migration/zero-cost`; añade endpoints `/api/ota/telemetry`, `/api/admin/ota/*`, `/api/version` 7.0.0 y guardas 404 anti-MIME HTML en estáticos faltantes.

### 2.3 Recuperación Auth, Admin, Cloud Sync y Pruebas
- `src/App.tsx` — Conserva `React.lazy`, `<React.Suspense>` y el indicador Gorilla de `migration/zero-cost`; añade evento `ota-just-installed` al arrancar y pantalla de recuperación si falta perfil activo.
- `src/main.tsx` — Envuelve la aplicación con `<ErrorBoundary>` y recupera chunks obsoletos (`vite:preloadError`) respetando entrenamientos activos.
- `src/utils/startupPerf.ts` — Añade flag diagnóstico `authInitWatchdogTriggered`.
- `src/components/AuthProvider.tsx` — Conserva import `{ auth, db, firebaseConfig } from '../firebase'` y el guardia `lazcakong-zero-cost-test` de `migration/zero-cost`; añade watchdog `3500ms` y `getRedirectResult(auth)`.
- `src/utils/firebaseSync.ts` — Conserva `{ auth, db, firebaseConfig }` y guardia `lazcakong-zero-cost-test` de `migration/zero-cost`; añade `createSingleUseInviteDetailed`, `revokeInviteTokenDetailed`, `fetchInvitesAdminResult` y timeouts de 12s.
- `src/utils/nativeAuth.ts` — Conserva `{ auth, firebaseConfig, googleProvider }` y manejo específico `[16]` (`auth/native-google-account-reauth-failed`) de `migration/zero-cost`; añade fallback `signInWithRedirect`/`linkWithRedirect` cuando se bloquea popup web.
- `src/hooks/useGymState.ts` — Conserva manejo `auth/native-google-account-reauth-failed` de `migration/zero-cost`; añade `redirectError`, timeout de `3500ms` en `getIdToken()`, `sessionServerValidatedRef` y `auth/redirect-initiated`.
- `src/views/AdminView.tsx` — Añade hidratación de datos de atletas en la nube, `<AdminUpdateCenter />` y modal de confirmación interno (sin `window.confirm`).
- `src/views/SettingsCloudView.tsx` — Conserva el control de reversión APK de `cloudflare-preview` de `migration/zero-cost` y reemplaza el punto parpadeante decorativo por icono limpio.
- `src/components/InstallApkModal.tsx` — Integra enlace directo al APK oficial de GitHub Releases y feedback detallado en creación/listado/revocación de invitaciones.
- `src/components/ProfileModal.tsx` — Reemplaza `window.confirm()` por diálogo interno seguro.
- `src/server/firebaseAdminServer.ts` — Añade fallbacks REST con token de usuario autorizado para panel Admin cuando el Admin SDK carezca de IAM.
- `src/server/authMigrationController.ts` — Activa ruta REST de administrador e informa error 503 claro si falta `FIREBASE_SERVICE_ACCOUNT_JSON`.
- `src/server/__tests__/otaUpdateSystemSuite.ts` — Suite ampliada a 11 comprobaciones OTA/Ed25519/cuarentena/versionCode `70000`.
- `src/server/__tests__/nativeCapacitorStage7aSuite.ts`, `nativeGoogleAuthSuite.ts`, `pwaStartupSessionSuite.ts` — Preservan íntegramente los guardas `CI_ANDROID_ONLY`, `[16]` y `RUN_LIVE_FIREBASE_BENCHMARK` de `migration/zero-cost`.

---

## 3. Archivos y Recursos de `migration/zero-cost` 100% INTACTOS (NO sobrescritos)

- **Infraestructura Cloudflare & Zero-Cost**: `cloudflare/*`, `wrangler.jsonc`, `wrangler.app-preview.jsonc`, `.github/workflows/cloudflare-app-preview.yml`, `.github/workflows/firestore-rules-test.yml`, `firebase.preview-emulators.json`, `firestore.preview.rules`, `firestore.rules`, `docs/*.md`, `scripts/check-*.mjs`, `scripts/zero-cost-*.mjs`, `scripts/preview-session.test.mjs`.
- **Biblioteca de Ejercicios & Demos de Cuello**: `src/data/exerciseLibrary.json`, `src/data/exerciseLibrary.ts`, `src/data/exerciseAliases.json`, `src/data/neckExerciseAdditions.ts`, `src/components/NeckMovementDemo.tsx`, `src/components/NeckMovementDemo.css`, `src/utils/neckMovementSpec.ts`, `src/components/ExerciseThumbnail.tsx`, `src/components/ExerciseDetailModal.tsx`, `src/views/ExerciseLibraryView.tsx`, `src/server/__tests__/neckLibrarySuite.ts`, y todos los archivos multimedia de `public/exercise-library/*` (10 archivos) y `public/images/*` (2 diagramas anatómicos).
- **Coach IA Local / Fallback Zero-Cost**: `src/components/CoachChatModal.tsx`, `src/components/AIRoutineGeneratorModal.tsx`, `src/server/geminiModel.ts`, `src/server/coachController.ts`, `src/server/geminiMachineScanner.ts`, `src/server/geminiRoutineGenerator.ts`, `src/server/geminiVisionRoutineExtractor.ts`, `src/utils/coachLocalFallback.ts`, `src/utils/coachServiceDiagnostics.ts`, `src/utils/coachContextEngine.ts`, `src/server/__tests__/coachLaunchReadinessSuite.ts`, `src/server/__tests__/coachNoHangSuite.ts`.
- **Base y plugins nativos**: `package.json`, `package-lock.json`, `capacitor.config.ts`, `src/firebase.ts`, `src/views/TodayView.tsx`, `src/utils/calorieCalculator.ts`, `src/utils/otaCompatibility.ts`, `src/server/__tests__/realFirebaseEmulatorSuite.ts`, `.gitignore`, `RestTimer*`, `RestAlarmReceiver`, `RestCompleteLockActivity`, `MainActivity.java`, `AndroidManifest.xml`, logo del gorila.

---

## 4. Manifiesto SHA-256 de archivos incluidos en `payload/`

| Archivo | Bytes | SHA-256 |
|---|---:|---|
| `.env.example` | 4038 | `7a4967b4c88b4e5df4fef9632a2f552c9b0bbac7dceb46a784f1fb310e222819` |
| `.github/workflows/android-apk.yml` | 22974 | `0a7dc0add6963d4bfe2b0f755f1d24919765b31d06d04899be57067c6b9713f5` |
| `android/app/build.gradle` | 4181 | `3fd7affca394535d62b3c3bda7b3b1ef30b0502f8c15e6bea9d8e86a30b01283` |
| `android/gradlew.bat` | 2937 | `1d297e00bd21de3ace22b4d7f2de1f9dfa858883d66bbf7c1ccbecccec8f4f3b` |
| `public/sw.js` | 14198 | `845ac8551e6584ca791dede18df1a0a1678c156c8e25f2013b7839f0f7430161` |
| `scripts/package-ota-bundle.mjs` | 11134 | `284ce33e50fe99035cec41ff76c4565c38188438b9a046c522f831dd7b5ac5c3` |
| `server.ts` | 30612 | `545c680f08b1c64d5231867a44424676930907966208fc3ae5a20961bcba4607` |
| `src/App.tsx` | 29358 | `d89d3ccd8dba70e5ab6a73dfcc56fc16ce6d0ee90ee34f5d674735f186127737` |
| `src/components/AdminUpdateCenter.tsx` | 29974 | `25d5ad7fb4914d6c188166e23cb71fcea27a5239cdc7109599f5f5bfa0a967f5` |
| `src/components/AuthProvider.tsx` | 8450 | `2725fc7c01ee5de9bb77e47025b1040f6e0393d86bb3c047c053d087a5b58ff6` |
| `src/components/ErrorBoundary.tsx` | 3324 | `5adad0cebc02a3b2278223cd72ef9d4da04ebcb97817aceefd79286b3da96c45` |
| `src/components/InstallApkModal.tsx` | 50539 | `adae90628606471d6e841e4a95e58280f002a80312afa1b092a1dc3c37d24152` |
| `src/components/ProfileModal.tsx` | 13673 | `9320faa4388e13d0b6f80aefaef399b88e45bdf91d49b4bd7211294a12bb269c` |
| `src/components/UpdateBanner.tsx` | 10323 | `1d9a12f656404dda93a53f54493912435b7a27230d762c511dcc8844e51ab847` |
| `src/hooks/useAppUpdate.ts` | 21392 | `97f604a0ecd29304cd77d4e98d3b4d7b24fb7f685e8b83ea13fb09beaa9dd21d` |
| `src/hooks/useGymState.ts` | 215277 | `672d99d7025643cf5f40890afa4afaff00c2daf81465042b7824656fd3c19eae` |
| `src/main.tsx` | 5379 | `be800676748cb377546048c6de302e2ea1aae62bcbb0eb0b4235b5903c325ad7` |
| `src/server/__tests__/nativeCapacitorStage7aSuite.ts` | 9526 | `cf93effa4b6e1508857adeebe6fe394a14c0ffd7c15761e3232501a800d7f126` |
| `src/server/__tests__/nativeGoogleAuthSuite.ts` | 12382 | `2d0769f87a5cd0b4fbefd84cdbd3309da71b7863c3f461ca40c1261f759830ec` |
| `src/server/__tests__/otaUpdateSystemSuite.ts` | 23488 | `987ec59b1bb4acb3f0117524429baaf9b855017546647395747a4bbcdfd5b612` |
| `src/server/__tests__/pwaStartupSessionSuite.ts` | 20759 | `7f950bf43173e9406aaebea24fad26dd9e0f3121777914020d12f47da83364d2` |
| `src/server/__tests__/recoveryBatchFixes.test.ts` | 11671 | `0a31f64eac3f86322f663d2932619fa97ffcbdeed3ddfed5fbad32cb47cfc1b2` |
| `src/server/authMigrationController.ts` | 65309 | `396989ed74d674cb981505e79235e36fba735fc49fa830d17fff86041d4fbebf` |
| `src/server/firebaseAdminServer.ts` | 29927 | `5dfbb73f0d980a9085c69c3e77f7d5b15e04fe15af37f8d9817086aed8eb3fd3` |
| `src/server/otaUpdateController.ts` | 29828 | `1d1a9ecbaac87710d7bbd0587b63add87d852074ca944a81d92db72ef50a9c3b` |
| `src/utils/firebaseSync.ts` | 46949 | `86c19fc3d8362d1a49e85678ffb876035660f504301ab4502b55125a2c328b8a` |
| `src/utils/nativeAuth.ts` | 11063 | `6bf3d3b156ba6d0a71d260460b2135e6c658b60836cc2a926d498aa116ab178f` |
| `src/utils/otaUpdateEngine.ts` | 29314 | `b326b42ffe2ea914cc93f79755e9cb1509b5c2e22db705be8aa4dabbb403949f` |
| `src/utils/startupPerf.ts` | 2174 | `67104316ac86242cc3bcd4a78468cf8a3e19f39a06e5b083fa04fe5eef34f0ca` |
| `src/utils/updateApp.ts` | 8616 | `6819b1f03314136275bb6321b3672abeb5876de9bb7637336fe9a8e5a5a52ce5` |
| `src/views/AdminView.tsx` | 49539 | `5bc184ab6a485d6b5ac23f811e3ec666613a87f8c259e1ce13c5a76b4e65ddaf` |
| `src/views/SettingsCloudView.tsx` | 120562 | `c6035b422a88f5b9a6a8a79dec6eef8dd3d9a08e4404a3b4ada518fc2123695d` |
| `vite.config.ts` | 8278 | `2f6a144fcf6fbc755372653aeac39ff05963b23c4ea170bf1d170ab6ea08d714` |
